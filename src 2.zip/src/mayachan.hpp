//
//  mayachan.hpp
//  623
//
//  Created by 増田麻耶 on 2017/06/20.
//
//

#ifndef mayachan_hpp
#define mayachan_hpp

#include <stdio.h>
#include "ofMain.h"
#include <iostream>


class Mayachan{
    
    public:
    float x,y,vx,vy,degree,m,pos,a;
    
    Mayachan();  //constructor  same as the name of class
    void setup();
    void update();
    void draw();
  };

#endif /* mayachan_hpp */
