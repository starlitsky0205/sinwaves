//
//  mayachan.cpp
//  623
//
//  Created by 増田麻耶 on 2017/06/20.
//
//

#include "mayachan.hpp"


Mayachan::Mayachan(){
    //=void setup
    
    degree=0;
    //最少でok
    
}


void Mayachan::update(){
    degree=degree+0.1;
    if(degree>360){
        degree=0;
    }

}



void Mayachan::draw(){
    
    for(radius=-1000;radius<1000;radius=radius+1){
    x=radius;
    y=radius*sin(degree);
    ofSetColor(ofRandom(255), ofRandom(255), 255);
    ofDrawCircle(x,y,1,1);
    }
}
